interface AnimatedButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary';
  active?: boolean;
}

export function AnimatedButton({ 
  children, 
  onClick, 
  variant = 'primary',
  active = false 
}: AnimatedButtonProps) {
  return (
    <button
      onClick={onClick}
      className={`
        px-4 py-2 rounded-lg font-medium
        transition-all duration-200 ease-out
        ${variant === 'primary' 
          ? active 
            ? 'bg-blue-600 text-white shadow-lg scale-95' 
            : 'bg-blue-500 text-white hover:bg-blue-600 hover:shadow-md active:scale-95'
          : active
            ? 'bg-gray-300 text-gray-800 shadow-lg scale-95'
            : 'bg-gray-200 text-gray-700 hover:bg-gray-300 hover:shadow-md active:scale-95'
        }
        transform hover:scale-105
      `}
    >
      {children}
    </button>
  );
}
